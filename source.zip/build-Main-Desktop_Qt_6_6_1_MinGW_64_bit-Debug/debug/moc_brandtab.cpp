/****************************************************************************
** Meta object code from reading C++ file 'brandtab.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../GitHub/Main/brandtab.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'brandtab.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBrandTabENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBrandTabENDCLASS = QtMocHelpers::stringData(
    "BrandTab",
    "insertComparedSalesData",
    "",
    "month",
    "brandTapClicked",
    "monthIndexChanged",
    "monthPickButtonClicked",
    "durationPickButtonClicked",
    "searchButtonClicked",
    "hyundaiButttonClicked",
    "kiaButtonClicked",
    "genesisButtonClicked",
    "chevroletButtonClicked",
    "kgMobilityButtonClicked",
    "renaultButtonClicked",
    "bmwButtonClicked",
    "benzButtonClicked",
    "audiButtonClicked",
    "lexusButtonClicked",
    "porscheButtonClicked",
    "monthlyTotalSalesFind",
    "type",
    "BrandTotalSalesByPeriodFind",
    "extract1",
    "extract2",
    "monthlyBrandTotalSalesFind",
    "monthlySpecificBrandTotalSalesFind",
    "brand",
    "monthlyModelTotalSalesFind",
    "totalSalesData",
    "ModelTotalSalesByPeriodFind"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBrandTabENDCLASS_t {
    uint offsetsAndSizes[62];
    char stringdata0[9];
    char stringdata1[24];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[16];
    char stringdata5[18];
    char stringdata6[23];
    char stringdata7[26];
    char stringdata8[20];
    char stringdata9[22];
    char stringdata10[17];
    char stringdata11[21];
    char stringdata12[23];
    char stringdata13[24];
    char stringdata14[21];
    char stringdata15[17];
    char stringdata16[18];
    char stringdata17[18];
    char stringdata18[19];
    char stringdata19[21];
    char stringdata20[22];
    char stringdata21[5];
    char stringdata22[28];
    char stringdata23[9];
    char stringdata24[9];
    char stringdata25[27];
    char stringdata26[35];
    char stringdata27[6];
    char stringdata28[27];
    char stringdata29[15];
    char stringdata30[28];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBrandTabENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBrandTabENDCLASS_t qt_meta_stringdata_CLASSBrandTabENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "BrandTab"
        QT_MOC_LITERAL(9, 23),  // "insertComparedSalesData"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 5),  // "month"
        QT_MOC_LITERAL(40, 15),  // "brandTapClicked"
        QT_MOC_LITERAL(56, 17),  // "monthIndexChanged"
        QT_MOC_LITERAL(74, 22),  // "monthPickButtonClicked"
        QT_MOC_LITERAL(97, 25),  // "durationPickButtonClicked"
        QT_MOC_LITERAL(123, 19),  // "searchButtonClicked"
        QT_MOC_LITERAL(143, 21),  // "hyundaiButttonClicked"
        QT_MOC_LITERAL(165, 16),  // "kiaButtonClicked"
        QT_MOC_LITERAL(182, 20),  // "genesisButtonClicked"
        QT_MOC_LITERAL(203, 22),  // "chevroletButtonClicked"
        QT_MOC_LITERAL(226, 23),  // "kgMobilityButtonClicked"
        QT_MOC_LITERAL(250, 20),  // "renaultButtonClicked"
        QT_MOC_LITERAL(271, 16),  // "bmwButtonClicked"
        QT_MOC_LITERAL(288, 17),  // "benzButtonClicked"
        QT_MOC_LITERAL(306, 17),  // "audiButtonClicked"
        QT_MOC_LITERAL(324, 18),  // "lexusButtonClicked"
        QT_MOC_LITERAL(343, 20),  // "porscheButtonClicked"
        QT_MOC_LITERAL(364, 21),  // "monthlyTotalSalesFind"
        QT_MOC_LITERAL(386, 4),  // "type"
        QT_MOC_LITERAL(391, 27),  // "BrandTotalSalesByPeriodFind"
        QT_MOC_LITERAL(419, 8),  // "extract1"
        QT_MOC_LITERAL(428, 8),  // "extract2"
        QT_MOC_LITERAL(437, 26),  // "monthlyBrandTotalSalesFind"
        QT_MOC_LITERAL(464, 34),  // "monthlySpecificBrandTotalSale..."
        QT_MOC_LITERAL(499, 5),  // "brand"
        QT_MOC_LITERAL(505, 26),  // "monthlyModelTotalSalesFind"
        QT_MOC_LITERAL(532, 14),  // "totalSalesData"
        QT_MOC_LITERAL(547, 27)   // "ModelTotalSalesByPeriodFind"
    },
    "BrandTab",
    "insertComparedSalesData",
    "",
    "month",
    "brandTapClicked",
    "monthIndexChanged",
    "monthPickButtonClicked",
    "durationPickButtonClicked",
    "searchButtonClicked",
    "hyundaiButttonClicked",
    "kiaButtonClicked",
    "genesisButtonClicked",
    "chevroletButtonClicked",
    "kgMobilityButtonClicked",
    "renaultButtonClicked",
    "bmwButtonClicked",
    "benzButtonClicked",
    "audiButtonClicked",
    "lexusButtonClicked",
    "porscheButtonClicked",
    "monthlyTotalSalesFind",
    "type",
    "BrandTotalSalesByPeriodFind",
    "extract1",
    "extract2",
    "monthlyBrandTotalSalesFind",
    "monthlySpecificBrandTotalSalesFind",
    "brand",
    "monthlyModelTotalSalesFind",
    "totalSalesData",
    "ModelTotalSalesByPeriodFind"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBrandTabENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  152,    2, 0x08,    1 /* Private */,
       4,    0,  155,    2, 0x08,    3 /* Private */,
       5,    0,  156,    2, 0x08,    4 /* Private */,
       6,    0,  157,    2, 0x08,    5 /* Private */,
       7,    0,  158,    2, 0x08,    6 /* Private */,
       8,    0,  159,    2, 0x08,    7 /* Private */,
       9,    0,  160,    2, 0x08,    8 /* Private */,
      10,    0,  161,    2, 0x08,    9 /* Private */,
      11,    0,  162,    2, 0x08,   10 /* Private */,
      12,    0,  163,    2, 0x08,   11 /* Private */,
      13,    0,  164,    2, 0x08,   12 /* Private */,
      14,    0,  165,    2, 0x08,   13 /* Private */,
      15,    0,  166,    2, 0x08,   14 /* Private */,
      16,    0,  167,    2, 0x08,   15 /* Private */,
      17,    0,  168,    2, 0x08,   16 /* Private */,
      18,    0,  169,    2, 0x08,   17 /* Private */,
      19,    0,  170,    2, 0x08,   18 /* Private */,
      20,    2,  171,    2, 0x08,   19 /* Private */,
      22,    2,  176,    2, 0x08,   22 /* Private */,
      25,    1,  181,    2, 0x08,   25 /* Private */,
      26,    2,  184,    2, 0x08,   27 /* Private */,
      28,    2,  189,    2, 0x08,   30 /* Private */,
      30,    2,  194,    2, 0x08,   33 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::QString, QMetaType::QString, QMetaType::Int,    3,   21,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   23,   24,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::QString, QMetaType::QString, QMetaType::QString,    3,   27,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,   29,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   23,   24,

       0        // eod
};

Q_CONSTINIT const QMetaObject BrandTab::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSBrandTabENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBrandTabENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBrandTabENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BrandTab, std::true_type>,
        // method 'insertComparedSalesData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'brandTapClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'monthIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'monthPickButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'durationPickButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'searchButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hyundaiButttonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'kiaButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'genesisButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'chevroletButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'kgMobilityButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'renaultButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bmwButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'benzButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'audiButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'lexusButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'porscheButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'monthlyTotalSalesFind'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'BrandTotalSalesByPeriodFind'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'monthlyBrandTotalSalesFind'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'monthlySpecificBrandTotalSalesFind'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'monthlyModelTotalSalesFind'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'ModelTotalSalesByPeriodFind'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>
    >,
    nullptr
} };

void BrandTab::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BrandTab *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->insertComparedSalesData((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->brandTapClicked(); break;
        case 2: _t->monthIndexChanged(); break;
        case 3: _t->monthPickButtonClicked(); break;
        case 4: _t->durationPickButtonClicked(); break;
        case 5: _t->searchButtonClicked(); break;
        case 6: _t->hyundaiButttonClicked(); break;
        case 7: _t->kiaButtonClicked(); break;
        case 8: _t->genesisButtonClicked(); break;
        case 9: _t->chevroletButtonClicked(); break;
        case 10: _t->kgMobilityButtonClicked(); break;
        case 11: _t->renaultButtonClicked(); break;
        case 12: _t->bmwButtonClicked(); break;
        case 13: _t->benzButtonClicked(); break;
        case 14: _t->audiButtonClicked(); break;
        case 15: _t->lexusButtonClicked(); break;
        case 16: _t->porscheButtonClicked(); break;
        case 17: { QString _r = _t->monthlyTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 18: _t->BrandTotalSalesByPeriodFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 19: _t->monthlyBrandTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 20: { QString _r = _t->monthlySpecificBrandTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 21: _t->monthlyModelTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 22: _t->ModelTotalSalesByPeriodFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObject *BrandTab::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BrandTab::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBrandTabENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int BrandTab::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
