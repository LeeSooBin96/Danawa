/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *page_2;
    QLabel *label_4;
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_3;
    QLabel *label_5;
    QPushButton *pushButton_6;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QPushButton *pushButton_15;
    QWidget *page_3;
    QLabel *label_15;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QLabel *label_20;
    QPushButton *pushButton_9;
    QPushButton *pushButton_17;
    QWidget *page_4;
    QLabel *label_21;
    QStackedWidget *stackedWidget_2;
    QWidget *page_6;
    QPushButton *pushButton_10;
    QLabel *label_23;
    QLabel *label_22;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_7;
    QPushButton *pushButton_19;
    QWidget *page_7;
    QLabel *label_25;
    QLabel *label_26;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QWidget *page_8;
    QLabel *label_28;
    QPushButton *pushButton_14;
    QLabel *label_24;
    QWidget *page_5;
    QLabel *label_27;
    QLabel *label_29;
    QStackedWidget *stackedWidget_3;
    QWidget *page_9;
    QPushButton *pushButton_13;
    QLabel *label_30;
    QLabel *label_31;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_10;
    QLabel *label_32;
    QLineEdit *lineEdit_9;
    QPushButton *pushButton_20;
    QWidget *page_10;
    QLabel *label_35;
    QLabel *label_36;
    QPushButton *pushButton_16;
    QWidget *page_11;
    QLabel *label_37;
    QPushButton *pushButton_18;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName("Widget");
        Widget->resize(851, 620);
        stackedWidget = new QStackedWidget(Widget);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setGeometry(QRect(9, 9, 817, 611));
        stackedWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        page = new QWidget();
        page->setObjectName("page");
        label = new QLabel(page);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 30, 771, 221));
        label->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton = new QPushButton(page);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(330, 480, 121, 51));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;\n"
""));
        label_2 = new QLabel(page);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(60, 270, 691, 51));
        QFont font1;
        font1.setPointSize(26);
        font1.setBold(true);
        label_2->setFont(font1);
        label_3 = new QLabel(page);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(180, 320, 441, 81));
        label_3->setFont(font1);
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        label_4 = new QLabel(page_2);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(20, 20, 221, 81));
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        lineEdit = new QLineEdit(page_2);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(260, 80, 371, 41));
        QFont font2;
        font2.setPointSize(14);
        lineEdit->setFont(font2);
        lineEdit->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
""));
        pushButton_2 = new QPushButton(page_2);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(260, 180, 371, 41));
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
"color: rgb(252, 252, 252);\n"
"background-color: rgb(23, 0, 200);\n"
"\n"
"border-radius: 10px;"));
        lineEdit_2 = new QLineEdit(page_2);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(260, 130, 371, 41));
        lineEdit_2->setFont(font2);
        lineEdit_2->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
""));
        pushButton_3 = new QPushButton(page_2);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(260, 230, 111, 41));
        pushButton_3->setFont(font);
        pushButton_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(23, 0, 200);\n"
"\n"
"border-radius: 10px;"));
        pushButton_4 = new QPushButton(page_2);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(380, 230, 131, 41));
        pushButton_4->setFont(font);
        pushButton_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(23, 0, 200);\n"
"\n"
"border-radius: 10px;"));
        pushButton_5 = new QPushButton(page_2);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(520, 230, 111, 41));
        pushButton_5->setFont(font);
        pushButton_5->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(23, 0, 200);\n"
"\n"
"border-radius: 10px;"));
        checkBox = new QCheckBox(page_2);
        checkBox->setObjectName("checkBox");
        checkBox->setGeometry(QRect(260, 50, 111, 22));
        checkBox->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        checkBox_2 = new QCheckBox(page_2);
        checkBox_2->setObjectName("checkBox_2");
        checkBox_2->setGeometry(QRect(450, 50, 71, 22));
        checkBox_2->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        checkBox_3 = new QCheckBox(page_2);
        checkBox_3->setObjectName("checkBox_3");
        checkBox_3->setGeometry(QRect(530, 50, 101, 22));
        checkBox_3->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_5 = new QLabel(page_2);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(240, 390, 91, 16));
        QFont font3;
        font3.setPointSize(9);
        label_5->setFont(font3);
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_5->setAlignment(Qt::AlignCenter);
        pushButton_6 = new QPushButton(page_2);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(520, 20, 111, 24));
        pushButton_6->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_6 = new QLabel(page_2);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(340, 390, 101, 16));
        label_6->setFont(font3);
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_6->setAlignment(Qt::AlignCenter);
        label_7 = new QLabel(page_2);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(450, 390, 91, 16));
        label_7->setFont(font3);
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_7->setAlignment(Qt::AlignCenter);
        label_8 = new QLabel(page_2);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(550, 390, 101, 16));
        label_8->setFont(font3);
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_8->setAlignment(Qt::AlignCenter);
        label_9 = new QLabel(page_2);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(240, 300, 91, 81));
        label_9->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
"border-image: url(:/Resources/NaverImg.PNG);"));
        label_10 = new QLabel(page_2);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(350, 300, 91, 81));
        label_10->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
"border-image: url(:/Resources/KaKaoImg.PNG);"));
        label_11 = new QLabel(page_2);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(450, 300, 91, 81));
        label_11->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
"border-image: url(:/Resources/FacebookImg.PNG);"));
        label_12 = new QLabel(page_2);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(550, 300, 91, 81));
        label_12->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
"border-image: url(:/Resources/enuriImg.PNG);"));
        label_13 = new QLabel(page_2);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(240, 430, 421, 91));
        label_13->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
"border-image: url(:/Resources/adImg.PNG);"));
        label_14 = new QLabel(page_2);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(240, 540, 411, 20));
        QFont font4;
        font4.setPointSize(10);
        label_14->setFont(font4);
        label_14->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_14->setAlignment(Qt::AlignCenter);
        pushButton_15 = new QPushButton(page_2);
        pushButton_15->setObjectName("pushButton_15");
        pushButton_15->setGeometry(QRect(380, 570, 101, 31));
        pushButton_15->setFont(font);
        pushButton_15->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        label_15 = new QLabel(page_3);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(270, 20, 271, 41));
        QFont font5;
        font5.setPointSize(20);
        font5.setBold(true);
        label_15->setFont(font5);
        label_15->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        label_15->setAlignment(Qt::AlignCenter);
        lineEdit_3 = new QLineEdit(page_3);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(230, 210, 371, 41));
        lineEdit_3->setFont(font2);
        lineEdit_3->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        lineEdit_4 = new QLineEdit(page_3);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setGeometry(QRect(230, 270, 371, 41));
        lineEdit_4->setFont(font2);
        lineEdit_4->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        lineEdit_5 = new QLineEdit(page_3);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setGeometry(QRect(230, 330, 371, 41));
        lineEdit_5->setFont(font2);
        lineEdit_5->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        lineEdit_6 = new QLineEdit(page_3);
        lineEdit_6->setObjectName("lineEdit_6");
        lineEdit_6->setGeometry(QRect(230, 390, 371, 41));
        lineEdit_6->setFont(font2);
        lineEdit_6->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        lineEdit_6->setEchoMode(QLineEdit::Password);
        label_16 = new QLabel(page_3);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(180, 210, 41, 41));
        label_16->setFont(font);
        label_16->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        label_17 = new QLabel(page_3);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(140, 270, 81, 41));
        label_17->setFont(font);
        label_17->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        label_18 = new QLabel(page_3);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(160, 330, 61, 41));
        label_18->setFont(font);
        label_18->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        label_19 = new QLabel(page_3);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(140, 390, 81, 41));
        label_19->setFont(font);
        label_19->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        pushButton_7 = new QPushButton(page_3);
        pushButton_7->setObjectName("pushButton_7");
        pushButton_7->setGeometry(QRect(610, 270, 101, 41));
        pushButton_7->setFont(font);
        pushButton_7->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(199, 199, 199);\n"
"border-radius: 10px;"));
        pushButton_8 = new QPushButton(page_3);
        pushButton_8->setObjectName("pushButton_8");
        pushButton_8->setGeometry(QRect(610, 330, 101, 41));
        pushButton_8->setFont(font);
        pushButton_8->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(199, 199, 199);\n"
"border-radius: 10px;"));
        label_20 = new QLabel(page_3);
        label_20->setObjectName("label_20");
        label_20->setGeometry(QRect(220, 80, 381, 101));
        label_20->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);"));
        pushButton_9 = new QPushButton(page_3);
        pushButton_9->setObjectName("pushButton_9");
        pushButton_9->setGeometry(QRect(280, 470, 111, 41));
        pushButton_9->setFont(font);
        pushButton_9->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        pushButton_17 = new QPushButton(page_3);
        pushButton_17->setObjectName("pushButton_17");
        pushButton_17->setGeometry(QRect(410, 470, 111, 41));
        pushButton_17->setFont(font);
        pushButton_17->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName("page_4");
        label_21 = new QLabel(page_4);
        label_21->setObjectName("label_21");
        label_21->setGeometry(QRect(290, 10, 271, 41));
        label_21->setFont(font5);
        label_21->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_21->setAlignment(Qt::AlignCenter);
        stackedWidget_2 = new QStackedWidget(page_4);
        stackedWidget_2->setObjectName("stackedWidget_2");
        stackedWidget_2->setGeometry(QRect(180, 200, 481, 241));
        stackedWidget_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        page_6 = new QWidget();
        page_6->setObjectName("page_6");
        pushButton_10 = new QPushButton(page_6);
        pushButton_10->setObjectName("pushButton_10");
        pushButton_10->setGeometry(QRect(140, 170, 111, 41));
        pushButton_10->setFont(font);
        pushButton_10->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        label_23 = new QLabel(page_6);
        label_23->setObjectName("label_23");
        label_23->setGeometry(QRect(10, 80, 81, 41));
        label_23->setFont(font);
        label_23->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        label_22 = new QLabel(page_6);
        label_22->setObjectName("label_22");
        label_22->setGeometry(QRect(50, 20, 41, 41));
        label_22->setFont(font);
        label_22->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        lineEdit_8 = new QLineEdit(page_6);
        lineEdit_8->setObjectName("lineEdit_8");
        lineEdit_8->setGeometry(QRect(100, 80, 371, 41));
        lineEdit_8->setFont(font2);
        lineEdit_8->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        lineEdit_7 = new QLineEdit(page_6);
        lineEdit_7->setObjectName("lineEdit_7");
        lineEdit_7->setGeometry(QRect(100, 20, 371, 41));
        lineEdit_7->setFont(font2);
        lineEdit_7->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        pushButton_19 = new QPushButton(page_6);
        pushButton_19->setObjectName("pushButton_19");
        pushButton_19->setGeometry(QRect(270, 170, 111, 41));
        pushButton_19->setFont(font);
        pushButton_19->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget_2->addWidget(page_6);
        page_7 = new QWidget();
        page_7->setObjectName("page_7");
        label_25 = new QLabel(page_7);
        label_25->setObjectName("label_25");
        label_25->setGeometry(QRect(130, 50, 251, 21));
        label_25->setFont(font);
        label_25->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_26 = new QLabel(page_7);
        label_26->setObjectName("label_26");
        label_26->setGeometry(QRect(140, 110, 231, 21));
        QFont font6;
        font6.setPointSize(13);
        label_26->setFont(font6);
        label_26->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_11 = new QPushButton(page_7);
        pushButton_11->setObjectName("pushButton_11");
        pushButton_11->setGeometry(QRect(90, 170, 161, 41));
        pushButton_11->setFont(font);
        pushButton_11->setStyleSheet(QString::fromUtf8("border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        pushButton_12 = new QPushButton(page_7);
        pushButton_12->setObjectName("pushButton_12");
        pushButton_12->setGeometry(QRect(260, 170, 151, 41));
        pushButton_12->setFont(font);
        pushButton_12->setStyleSheet(QString::fromUtf8("border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget_2->addWidget(page_7);
        page_8 = new QWidget();
        page_8->setObjectName("page_8");
        label_28 = new QLabel(page_8);
        label_28->setObjectName("label_28");
        label_28->setGeometry(QRect(10, 40, 461, 21));
        label_28->setFont(font);
        pushButton_14 = new QPushButton(page_8);
        pushButton_14->setObjectName("pushButton_14");
        pushButton_14->setGeometry(QRect(190, 160, 131, 41));
        pushButton_14->setFont(font);
        pushButton_14->setStyleSheet(QString::fromUtf8("border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget_2->addWidget(page_8);
        label_24 = new QLabel(page_4);
        label_24->setObjectName("label_24");
        label_24->setGeometry(QRect(240, 90, 381, 101));
        label_24->setStyleSheet(QString::fromUtf8("color: rgb(8, 8, 8);"));
        stackedWidget->addWidget(page_4);
        stackedWidget_2->raise();
        label_21->raise();
        label_24->raise();
        page_5 = new QWidget();
        page_5->setObjectName("page_5");
        label_27 = new QLabel(page_5);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(230, 100, 381, 101));
        label_27->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_29 = new QLabel(page_5);
        label_29->setObjectName("label_29");
        label_29->setGeometry(QRect(280, 20, 271, 41));
        label_29->setFont(font5);
        label_29->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_29->setAlignment(Qt::AlignCenter);
        stackedWidget_3 = new QStackedWidget(page_5);
        stackedWidget_3->setObjectName("stackedWidget_3");
        stackedWidget_3->setGeometry(QRect(180, 230, 481, 291));
        stackedWidget_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        page_9 = new QWidget();
        page_9->setObjectName("page_9");
        pushButton_13 = new QPushButton(page_9);
        pushButton_13->setObjectName("pushButton_13");
        pushButton_13->setGeometry(QRect(130, 230, 111, 41));
        pushButton_13->setFont(font);
        pushButton_13->setStyleSheet(QString::fromUtf8("border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        label_30 = new QLabel(page_9);
        label_30->setObjectName("label_30");
        label_30->setGeometry(QRect(0, 150, 81, 41));
        label_30->setFont(font);
        label_31 = new QLabel(page_9);
        label_31->setObjectName("label_31");
        label_31->setGeometry(QRect(40, 30, 41, 41));
        label_31->setFont(font);
        lineEdit_11 = new QLineEdit(page_9);
        lineEdit_11->setObjectName("lineEdit_11");
        lineEdit_11->setGeometry(QRect(90, 90, 371, 41));
        lineEdit_11->setFont(font2);
        lineEdit_10 = new QLineEdit(page_9);
        lineEdit_10->setObjectName("lineEdit_10");
        lineEdit_10->setGeometry(QRect(90, 30, 371, 41));
        lineEdit_10->setFont(font2);
        label_32 = new QLabel(page_9);
        label_32->setObjectName("label_32");
        label_32->setGeometry(QRect(0, 90, 81, 41));
        label_32->setFont(font);
        label_32->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_9 = new QLineEdit(page_9);
        lineEdit_9->setObjectName("lineEdit_9");
        lineEdit_9->setGeometry(QRect(90, 150, 371, 41));
        lineEdit_9->setFont(font2);
        pushButton_20 = new QPushButton(page_9);
        pushButton_20->setObjectName("pushButton_20");
        pushButton_20->setGeometry(QRect(260, 230, 111, 41));
        pushButton_20->setFont(font);
        pushButton_20->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget_3->addWidget(page_9);
        page_10 = new QWidget();
        page_10->setObjectName("page_10");
        label_35 = new QLabel(page_10);
        label_35->setObjectName("label_35");
        label_35->setGeometry(QRect(100, 40, 291, 31));
        label_35->setFont(font);
        label_35->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        label_36 = new QLabel(page_10);
        label_36->setObjectName("label_36");
        label_36->setGeometry(QRect(130, 110, 231, 21));
        label_36->setFont(font6);
        label_36->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);"));
        pushButton_16 = new QPushButton(page_10);
        pushButton_16->setObjectName("pushButton_16");
        pushButton_16->setGeometry(QRect(160, 180, 161, 41));
        pushButton_16->setFont(font);
        pushButton_16->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget_3->addWidget(page_10);
        page_11 = new QWidget();
        page_11->setObjectName("page_11");
        label_37 = new QLabel(page_11);
        label_37->setObjectName("label_37");
        label_37->setGeometry(QRect(10, 40, 461, 31));
        label_37->setFont(font);
        pushButton_18 = new QPushButton(page_11);
        pushButton_18->setObjectName("pushButton_18");
        pushButton_18->setGeometry(QRect(180, 160, 131, 41));
        pushButton_18->setFont(font);
        pushButton_18->setStyleSheet(QString::fromUtf8("border-radius: 10px;\n"
"background-color: rgb(254, 254, 254);\n"
"border:2px solid;"));
        stackedWidget_3->addWidget(page_11);
        stackedWidget->addWidget(page_5);

        retranslateUi(Widget);

        stackedWidget->setCurrentIndex(0);
        stackedWidget_2->setCurrentIndex(0);
        stackedWidget_3->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        label->setText(QString());
        pushButton->setText(QCoreApplication::translate("Widget", "\354\213\234\354\236\221\355\225\230\352\270\260", nullptr));
        label_2->setStyleSheet(QCoreApplication::translate("Widget", "color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);", nullptr));
        label_2->setText(QCoreApplication::translate("Widget", "\353\270\214\353\236\234\353\223\234\353\263\204 / \354\260\250\354\242\205\353\263\204 \355\214\220\353\247\244\353\237\211 \353\260\217 \354\240\220\354\234\240\354\234\250 \355\231\225\354\235\270\354\235\200 \354\227\254\352\270\260", nullptr));
        label_3->setStyleSheet(QCoreApplication::translate("Widget", "color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);", nullptr));
        label_3->setText(QCoreApplication::translate("Widget", "\354\235\264\352\263\263 danawa \354\231\200 \355\225\250\352\273\230\355\225\230\354\204\270\354\232\224", nullptr));
        label_4->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Widget", "\353\241\234\352\267\270\354\235\270", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Widget", "\354\225\204\354\235\264\353\224\224 \354\260\276\352\270\260", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Widget", "\353\271\204\353\260\200\353\262\210\355\230\270 \354\260\276\352\270\260", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Widget", "\355\232\214\354\233\220\352\260\200\354\236\205", nullptr));
        checkBox->setText(QCoreApplication::translate("Widget", "\353\241\234\352\267\270\354\235\270 \354\203\201\355\203\234 \354\234\240\354\247\200", nullptr));
        checkBox_2->setText(QCoreApplication::translate("Widget", "\354\235\274\353\260\230\355\232\214\354\233\220", nullptr));
        checkBox_3->setText(QCoreApplication::translate("Widget", "\355\230\221\353\240\245\354\202\254 \352\264\200\353\246\254\354\236\220", nullptr));
        label_5->setText(QCoreApplication::translate("Widget", "\353\204\244\354\235\264\353\262\204 \353\241\234\352\267\270\354\235\270", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Widget", "\353\271\204\353\241\234\352\267\270\354\235\270 \354\243\274\353\254\270\354\241\260\355\232\214", nullptr));
        label_6->setText(QCoreApplication::translate("Widget", "\354\271\264\354\271\264\354\230\244 \353\241\234\352\267\270\354\235\270", nullptr));
        label_7->setText(QCoreApplication::translate("Widget", "\355\216\230\354\235\264\354\212\244\353\266\201 \353\241\234\352\267\270\354\235\270", nullptr));
        label_8->setText(QCoreApplication::translate("Widget", "\354\227\220\353\210\204\353\246\254 \353\241\234\352\267\270\354\235\270", nullptr));
        label_9->setText(QString());
        label_10->setText(QString());
        label_11->setText(QString());
        label_12->setText(QString());
        label_13->setText(QString());
        label_14->setText(QCoreApplication::translate("Widget", "Copyright \302\251 connectwave Co., Ltd. All Rights Reserved.", nullptr));
        pushButton_15->setText(QCoreApplication::translate("Widget", "\354\235\264\354\240\204", nullptr));
        label_15->setText(QCoreApplication::translate("Widget", "\355\232\214\354\233\220\352\260\200\354\236\205", nullptr));
        lineEdit_4->setText(QCoreApplication::translate("Widget", "'-' \354\240\234\354\231\270", nullptr));
        label_16->setText(QCoreApplication::translate("Widget", "\354\204\261\355\225\250", nullptr));
        label_17->setText(QCoreApplication::translate("Widget", "\354\240\204\355\231\224\353\262\210\355\230\270", nullptr));
        label_18->setText(QCoreApplication::translate("Widget", "\354\225\204\354\235\264\353\224\224", nullptr));
        label_19->setText(QCoreApplication::translate("Widget", "\353\271\204\353\260\200\353\262\210\355\230\270", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Widget", "\354\244\221\353\263\265 \352\262\200\354\202\254", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Widget", "\354\244\221\353\263\265 \352\262\200\354\202\254", nullptr));
        label_20->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
        pushButton_9->setText(QCoreApplication::translate("Widget", "\354\203\235\354\204\261 \355\225\230\352\270\260", nullptr));
        pushButton_17->setText(QCoreApplication::translate("Widget", "\354\235\264\354\240\204", nullptr));
        label_21->setText(QCoreApplication::translate("Widget", "\354\225\204\354\235\264\353\224\224 \354\260\276\352\270\260", nullptr));
        pushButton_10->setText(QCoreApplication::translate("Widget", "\355\231\225\354\235\270", nullptr));
        label_23->setText(QCoreApplication::translate("Widget", "\354\240\204\355\231\224\353\262\210\355\230\270", nullptr));
        label_22->setText(QCoreApplication::translate("Widget", "\354\204\261\355\225\250", nullptr));
        lineEdit_8->setText(QCoreApplication::translate("Widget", "'-' \354\240\234\354\231\270", nullptr));
        pushButton_19->setText(QCoreApplication::translate("Widget", "\354\235\264\354\240\204", nullptr));
        label_25->setText(QCoreApplication::translate("Widget", "\355\232\214\354\233\220\353\213\230\354\235\230 \352\263\204\354\240\225\354\235\204 \354\260\276\354\225\230\354\212\265\353\213\210\353\213\244.", nullptr));
        label_26->setText(QString());
        pushButton_11->setText(QCoreApplication::translate("Widget", "\353\241\234\352\267\270\354\235\270 \355\231\224\353\251\264 \354\235\264\353\217\231", nullptr));
        pushButton_12->setText(QCoreApplication::translate("Widget", "\353\271\204\353\260\200\353\262\210\355\230\270 \354\260\276\352\270\260", nullptr));
        label_28->setText(QCoreApplication::translate("Widget", "\354\236\205\353\240\245\355\225\230\354\213\240 \354\240\225\353\263\264\354\231\200 \354\235\274\354\271\230\355\225\230\353\212\224 \352\263\204\354\240\225\354\235\264 \354\241\264\354\236\254\355\225\230\354\247\200 \354\225\212\354\212\265\353\213\210\353\213\244.", nullptr));
        pushButton_14->setText(QCoreApplication::translate("Widget", "\353\217\214\354\225\204\352\260\200\352\270\260", nullptr));
        label_24->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
        label_27->setText(QString());
        label_29->setText(QCoreApplication::translate("Widget", "\353\271\204\353\260\200\353\262\210\355\230\270 \354\260\276\352\270\260", nullptr));
        pushButton_13->setText(QCoreApplication::translate("Widget", "\355\231\225\354\235\270", nullptr));
        label_30->setText(QCoreApplication::translate("Widget", "\354\240\204\355\231\224\353\262\210\355\230\270", nullptr));
        label_31->setText(QCoreApplication::translate("Widget", "\354\204\261\355\225\250", nullptr));
        lineEdit_11->setText(QString());
        label_32->setText(QCoreApplication::translate("Widget", "\354\225\204\354\235\264\353\224\224", nullptr));
        lineEdit_9->setText(QCoreApplication::translate("Widget", "'-' \354\240\234\354\231\270", nullptr));
        pushButton_20->setText(QCoreApplication::translate("Widget", "\354\235\264\354\240\204", nullptr));
        label_35->setText(QCoreApplication::translate("Widget", "\355\232\214\354\233\220\353\213\230\354\235\230 \353\271\204\353\260\200\353\262\210\355\230\270\353\245\274 \354\260\276\354\225\230\354\212\265\353\213\210\353\213\244.", nullptr));
        label_36->setText(QString());
        pushButton_16->setText(QCoreApplication::translate("Widget", "\353\241\234\352\267\270\354\235\270 \355\231\224\353\251\264 \354\235\264\353\217\231", nullptr));
        label_37->setText(QCoreApplication::translate("Widget", "\354\236\205\353\240\245\355\225\230\354\213\240 \354\240\225\353\263\264\354\231\200 \354\235\274\354\271\230\355\225\230\353\212\224 \352\263\204\354\240\225\354\235\264 \354\241\264\354\236\254\355\225\230\354\247\200 \354\225\212\354\212\265\353\213\210\353\213\244.", nullptr));
        pushButton_18->setText(QCoreApplication::translate("Widget", "\353\217\214\354\225\204\352\260\200\352\270\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
