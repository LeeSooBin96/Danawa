#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtSql> // db추가작업

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_Select_Ask_PushButton_clicked();

    void on_Session_Ask_PushButton_clicked();

private:
    Ui::Widget *ui;
    QSqlDatabase DB_Connection; // db추가작업

};
#endif // WIDGET_H
