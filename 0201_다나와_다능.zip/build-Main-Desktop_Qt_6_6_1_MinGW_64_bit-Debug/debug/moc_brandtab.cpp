/****************************************************************************
** Meta object code from reading C++ file 'brandtab.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Main/brandtab.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'brandtab.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBrandTabENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBrandTabENDCLASS = QtMocHelpers::stringData(
    "BrandTab",
    "brandTapClicked",
    "",
    "monthIndexChanged",
    "monthPickButtonClicked",
    "durationPickButtonClicked",
    "searchButtonClicked",
    "hyundaiButttonClicked",
    "kiaButtonClicked",
    "genesisButtonClicked",
    "chevroletButtonClicked",
    "kgMobilityButtonClicked",
    "renaultButtonClicked",
    "bmwButtonClicked",
    "benzButtonClicked",
    "audiButtonClicked",
    "lexusButtonClicked",
    "porscheButtonClicked",
    "monthlyTotalSalesFind",
    "month",
    "type",
    "BrandTotalSalesByPeriodFind",
    "extract1",
    "extract2",
    "monthlyBrandTotalSalesFind",
    "monthlySpecificBrandTotalSalesFind",
    "brand",
    "monthlyModelTotalSalesFind",
    "totalSalesData"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBrandTabENDCLASS_t {
    uint offsetsAndSizes[58];
    char stringdata0[9];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[18];
    char stringdata4[23];
    char stringdata5[26];
    char stringdata6[20];
    char stringdata7[22];
    char stringdata8[17];
    char stringdata9[21];
    char stringdata10[23];
    char stringdata11[24];
    char stringdata12[21];
    char stringdata13[17];
    char stringdata14[18];
    char stringdata15[18];
    char stringdata16[19];
    char stringdata17[21];
    char stringdata18[22];
    char stringdata19[6];
    char stringdata20[5];
    char stringdata21[28];
    char stringdata22[9];
    char stringdata23[9];
    char stringdata24[27];
    char stringdata25[35];
    char stringdata26[6];
    char stringdata27[27];
    char stringdata28[15];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBrandTabENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBrandTabENDCLASS_t qt_meta_stringdata_CLASSBrandTabENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "BrandTab"
        QT_MOC_LITERAL(9, 15),  // "brandTapClicked"
        QT_MOC_LITERAL(25, 0),  // ""
        QT_MOC_LITERAL(26, 17),  // "monthIndexChanged"
        QT_MOC_LITERAL(44, 22),  // "monthPickButtonClicked"
        QT_MOC_LITERAL(67, 25),  // "durationPickButtonClicked"
        QT_MOC_LITERAL(93, 19),  // "searchButtonClicked"
        QT_MOC_LITERAL(113, 21),  // "hyundaiButttonClicked"
        QT_MOC_LITERAL(135, 16),  // "kiaButtonClicked"
        QT_MOC_LITERAL(152, 20),  // "genesisButtonClicked"
        QT_MOC_LITERAL(173, 22),  // "chevroletButtonClicked"
        QT_MOC_LITERAL(196, 23),  // "kgMobilityButtonClicked"
        QT_MOC_LITERAL(220, 20),  // "renaultButtonClicked"
        QT_MOC_LITERAL(241, 16),  // "bmwButtonClicked"
        QT_MOC_LITERAL(258, 17),  // "benzButtonClicked"
        QT_MOC_LITERAL(276, 17),  // "audiButtonClicked"
        QT_MOC_LITERAL(294, 18),  // "lexusButtonClicked"
        QT_MOC_LITERAL(313, 20),  // "porscheButtonClicked"
        QT_MOC_LITERAL(334, 21),  // "monthlyTotalSalesFind"
        QT_MOC_LITERAL(356, 5),  // "month"
        QT_MOC_LITERAL(362, 4),  // "type"
        QT_MOC_LITERAL(367, 27),  // "BrandTotalSalesByPeriodFind"
        QT_MOC_LITERAL(395, 8),  // "extract1"
        QT_MOC_LITERAL(404, 8),  // "extract2"
        QT_MOC_LITERAL(413, 26),  // "monthlyBrandTotalSalesFind"
        QT_MOC_LITERAL(440, 34),  // "monthlySpecificBrandTotalSale..."
        QT_MOC_LITERAL(475, 5),  // "brand"
        QT_MOC_LITERAL(481, 26),  // "monthlyModelTotalSalesFind"
        QT_MOC_LITERAL(508, 14)   // "totalSalesData"
    },
    "BrandTab",
    "brandTapClicked",
    "",
    "monthIndexChanged",
    "monthPickButtonClicked",
    "durationPickButtonClicked",
    "searchButtonClicked",
    "hyundaiButttonClicked",
    "kiaButtonClicked",
    "genesisButtonClicked",
    "chevroletButtonClicked",
    "kgMobilityButtonClicked",
    "renaultButtonClicked",
    "bmwButtonClicked",
    "benzButtonClicked",
    "audiButtonClicked",
    "lexusButtonClicked",
    "porscheButtonClicked",
    "monthlyTotalSalesFind",
    "month",
    "type",
    "BrandTotalSalesByPeriodFind",
    "extract1",
    "extract2",
    "monthlyBrandTotalSalesFind",
    "monthlySpecificBrandTotalSalesFind",
    "brand",
    "monthlyModelTotalSalesFind",
    "totalSalesData"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBrandTabENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  140,    2, 0x08,    1 /* Private */,
       3,    0,  141,    2, 0x08,    2 /* Private */,
       4,    0,  142,    2, 0x08,    3 /* Private */,
       5,    0,  143,    2, 0x08,    4 /* Private */,
       6,    0,  144,    2, 0x08,    5 /* Private */,
       7,    0,  145,    2, 0x08,    6 /* Private */,
       8,    0,  146,    2, 0x08,    7 /* Private */,
       9,    0,  147,    2, 0x08,    8 /* Private */,
      10,    0,  148,    2, 0x08,    9 /* Private */,
      11,    0,  149,    2, 0x08,   10 /* Private */,
      12,    0,  150,    2, 0x08,   11 /* Private */,
      13,    0,  151,    2, 0x08,   12 /* Private */,
      14,    0,  152,    2, 0x08,   13 /* Private */,
      15,    0,  153,    2, 0x08,   14 /* Private */,
      16,    0,  154,    2, 0x08,   15 /* Private */,
      17,    0,  155,    2, 0x08,   16 /* Private */,
      18,    2,  156,    2, 0x08,   17 /* Private */,
      21,    2,  161,    2, 0x08,   20 /* Private */,
      24,    1,  166,    2, 0x08,   23 /* Private */,
      25,    2,  169,    2, 0x08,   25 /* Private */,
      27,    3,  174,    2, 0x08,   28 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::QString, QMetaType::QString, QMetaType::Int,   19,   20,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   22,   23,
    QMetaType::Void, QMetaType::QString,   19,
    QMetaType::QString, QMetaType::QString, QMetaType::QString,   19,   26,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   19,   26,   28,

       0        // eod
};

Q_CONSTINIT const QMetaObject BrandTab::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSBrandTabENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBrandTabENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBrandTabENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BrandTab, std::true_type>,
        // method 'brandTapClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'monthIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'monthPickButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'durationPickButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'searchButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hyundaiButttonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'kiaButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'genesisButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'chevroletButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'kgMobilityButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'renaultButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bmwButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'benzButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'audiButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'lexusButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'porscheButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'monthlyTotalSalesFind'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'BrandTotalSalesByPeriodFind'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'monthlyBrandTotalSalesFind'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'monthlySpecificBrandTotalSalesFind'
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'monthlyModelTotalSalesFind'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>
    >,
    nullptr
} };

void BrandTab::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BrandTab *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->brandTapClicked(); break;
        case 1: _t->monthIndexChanged(); break;
        case 2: _t->monthPickButtonClicked(); break;
        case 3: _t->durationPickButtonClicked(); break;
        case 4: _t->searchButtonClicked(); break;
        case 5: _t->hyundaiButttonClicked(); break;
        case 6: _t->kiaButtonClicked(); break;
        case 7: _t->genesisButtonClicked(); break;
        case 8: _t->chevroletButtonClicked(); break;
        case 9: _t->kgMobilityButtonClicked(); break;
        case 10: _t->renaultButtonClicked(); break;
        case 11: _t->bmwButtonClicked(); break;
        case 12: _t->benzButtonClicked(); break;
        case 13: _t->audiButtonClicked(); break;
        case 14: _t->lexusButtonClicked(); break;
        case 15: _t->porscheButtonClicked(); break;
        case 16: { QString _r = _t->monthlyTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 17: _t->BrandTotalSalesByPeriodFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 18: _t->monthlyBrandTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 19: { QString _r = _t->monthlySpecificBrandTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 20: _t->monthlyModelTotalSalesFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        default: ;
        }
    }
}

const QMetaObject *BrandTab::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BrandTab::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBrandTabENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int BrandTab::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
