/****************************************************************************
** Meta object code from reading C++ file 'modeltab.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Main/modeltab.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'modeltab.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSModelTabENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSModelTabENDCLASS = QtMocHelpers::stringData(
    "ModelTab",
    "btnMonthClicked",
    "",
    "btnDurationClicked",
    "mMonthCurrentIndexChanged",
    "index",
    "btnShowClicked",
    "ShowDefault",
    "setCarType1",
    "setCarType2",
    "setCarType3",
    "setCarType4",
    "setCarType5",
    "setCarType6",
    "setCarType7",
    "setCarType8",
    "setCarType9",
    "setCarType10",
    "setCarType11",
    "setCarType12",
    "delCarType"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSModelTabENDCLASS_t {
    uint offsetsAndSizes[42];
    char stringdata0[9];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[19];
    char stringdata4[26];
    char stringdata5[6];
    char stringdata6[15];
    char stringdata7[12];
    char stringdata8[12];
    char stringdata9[12];
    char stringdata10[12];
    char stringdata11[12];
    char stringdata12[12];
    char stringdata13[12];
    char stringdata14[12];
    char stringdata15[12];
    char stringdata16[12];
    char stringdata17[13];
    char stringdata18[13];
    char stringdata19[13];
    char stringdata20[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSModelTabENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSModelTabENDCLASS_t qt_meta_stringdata_CLASSModelTabENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "ModelTab"
        QT_MOC_LITERAL(9, 15),  // "btnMonthClicked"
        QT_MOC_LITERAL(25, 0),  // ""
        QT_MOC_LITERAL(26, 18),  // "btnDurationClicked"
        QT_MOC_LITERAL(45, 25),  // "mMonthCurrentIndexChanged"
        QT_MOC_LITERAL(71, 5),  // "index"
        QT_MOC_LITERAL(77, 14),  // "btnShowClicked"
        QT_MOC_LITERAL(92, 11),  // "ShowDefault"
        QT_MOC_LITERAL(104, 11),  // "setCarType1"
        QT_MOC_LITERAL(116, 11),  // "setCarType2"
        QT_MOC_LITERAL(128, 11),  // "setCarType3"
        QT_MOC_LITERAL(140, 11),  // "setCarType4"
        QT_MOC_LITERAL(152, 11),  // "setCarType5"
        QT_MOC_LITERAL(164, 11),  // "setCarType6"
        QT_MOC_LITERAL(176, 11),  // "setCarType7"
        QT_MOC_LITERAL(188, 11),  // "setCarType8"
        QT_MOC_LITERAL(200, 11),  // "setCarType9"
        QT_MOC_LITERAL(212, 12),  // "setCarType10"
        QT_MOC_LITERAL(225, 12),  // "setCarType11"
        QT_MOC_LITERAL(238, 12),  // "setCarType12"
        QT_MOC_LITERAL(251, 10)   // "delCarType"
    },
    "ModelTab",
    "btnMonthClicked",
    "",
    "btnDurationClicked",
    "mMonthCurrentIndexChanged",
    "index",
    "btnShowClicked",
    "ShowDefault",
    "setCarType1",
    "setCarType2",
    "setCarType3",
    "setCarType4",
    "setCarType5",
    "setCarType6",
    "setCarType7",
    "setCarType8",
    "setCarType9",
    "setCarType10",
    "setCarType11",
    "setCarType12",
    "delCarType"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSModelTabENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  122,    2, 0x08,    1 /* Private */,
       3,    0,  123,    2, 0x08,    2 /* Private */,
       4,    1,  124,    2, 0x08,    3 /* Private */,
       6,    0,  127,    2, 0x08,    5 /* Private */,
       7,    0,  128,    2, 0x08,    6 /* Private */,
       8,    0,  129,    2, 0x08,    7 /* Private */,
       9,    0,  130,    2, 0x08,    8 /* Private */,
      10,    0,  131,    2, 0x08,    9 /* Private */,
      11,    0,  132,    2, 0x08,   10 /* Private */,
      12,    0,  133,    2, 0x08,   11 /* Private */,
      13,    0,  134,    2, 0x08,   12 /* Private */,
      14,    0,  135,    2, 0x08,   13 /* Private */,
      15,    0,  136,    2, 0x08,   14 /* Private */,
      16,    0,  137,    2, 0x08,   15 /* Private */,
      17,    0,  138,    2, 0x08,   16 /* Private */,
      18,    0,  139,    2, 0x08,   17 /* Private */,
      19,    0,  140,    2, 0x08,   18 /* Private */,
      20,    0,  141,    2, 0x08,   19 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject ModelTab::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSModelTabENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSModelTabENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSModelTabENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ModelTab, std::true_type>,
        // method 'btnMonthClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'btnDurationClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'mMonthCurrentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'btnShowClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'ShowDefault'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType3'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType4'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType5'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType6'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType7'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType8'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType9'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType10'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType11'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCarType12'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'delCarType'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void ModelTab::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ModelTab *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->btnMonthClicked(); break;
        case 1: _t->btnDurationClicked(); break;
        case 2: _t->mMonthCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->btnShowClicked(); break;
        case 4: _t->ShowDefault(); break;
        case 5: _t->setCarType1(); break;
        case 6: _t->setCarType2(); break;
        case 7: _t->setCarType3(); break;
        case 8: _t->setCarType4(); break;
        case 9: _t->setCarType5(); break;
        case 10: _t->setCarType6(); break;
        case 11: _t->setCarType7(); break;
        case 12: _t->setCarType8(); break;
        case 13: _t->setCarType9(); break;
        case 14: _t->setCarType10(); break;
        case 15: _t->setCarType11(); break;
        case 16: _t->setCarType12(); break;
        case 17: _t->delCarType(); break;
        default: ;
        }
    }
}

const QMetaObject *ModelTab::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ModelTab::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSModelTabENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ModelTab::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
